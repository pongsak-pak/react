const items =[
    {
      title :"pic1",
      thumbnaiUrl :"/pic/panda5.jpg"


    },
    {
      title :"pic2",
      thumbnaiUrl :"/pic/panda2.jpg"


    },
    {
      title :"pic3",
      thumbnaiUrl :"/pic/panda4.jpg"


    },
    {
      title :"pic4",
      thumbnaiUrl :"/pic/panda1.jpg"


    }
  ];
  export default items;