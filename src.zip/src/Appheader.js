function Appheader() {

    return (
    
          <header className="App">
            <img className = "App-header" src = "/pic/panda1.jpg"/>
    
    
          </header>
            );
          }
    export default Appheader;